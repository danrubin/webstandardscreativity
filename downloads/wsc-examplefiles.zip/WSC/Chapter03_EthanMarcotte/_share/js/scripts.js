/*-  Queue up functions to fire onload/onresize
----------------------------------------------------------------------*/
/*
	Text sizing
*/
addLoadEvent(buildTextSizer);
addLoadEvent(function() {
	if (readCookie("text-size")) {
		textIt(readCookie("text-size"));
	} else {
		textIt("txt-medium");
	}
});

/*
	"Current Issue" tabs
*/
addLoadEvent(buildCurrentIssueTabs);

/*
	IE fix for non-anchor hovers (top navigation, cover archive, etc.)
*/
if (document.all) {
	addLoadEvent(function() {
		ieHover(cssQuery("#navigation li"));
		ieHover(cssQuery("#restaurant-menu table tr"));
		ieHover(cssQuery("#cover-archive ul li.cover"));
	});
}
/*
	Add "remove text" handler to text fields
*/
addLoadEvent(initRemoveText);

/*
	Implement "smart" navigation hiding
*/
addLoadEvent(widthMonitor);
addResizeEvent(widthMonitor);


/*-  Text sizing
----------------------------------------------------------------------*/
/*
	Build controls text sizing
*/
function buildTextSizer() {
	if (document.getElementsByTagName) {
		var trigger = document.getElementsByTagName("body")[0];
		if (findWord("text-sizer", trigger.className) && document.createElement && document.getElementById) {
			if (document.getElementById("article-content")) {
				var container = document.getElementById("article-content");
			} else {
				var container = document.getElementById("content-primary");
			}

			if (container) {
				// Build elements
				var slugs = new Array("small", "medium", "large");
				var controlContainer = document.createElement("div");
				var topList = document.createElement("ul");
				var innerList = document.createElement("ul");
				var listItem = document.createElement("li");
				var span = document.createElement("span");
				var labelText = document.createTextNode("Text Size:")

				// Loop over the text size "slugs", and build a link for each one
				for (var i = 0; i < slugs.length; i++) {
					var text = document.createTextNode("A");
					var anchor = document.createElement("a");
					var item = document.createElement("li");

					anchor.appendChild(text);
					anchor.setAttribute("href", "javascript:textIt('txt-" + slugs[i] + "');");
					anchor.setAttribute("title", "Make the story text " + slugs[i] + ".");
					item.appendChild(anchor);
					item.setAttribute("id", "txt-" + slugs[i]);

					innerList.appendChild(item);
				}

				// Assemble everything, and insert it into the document
				span.className = "label";
				span.appendChild(labelText);
				listItem.appendChild(span);
				listItem.appendChild(innerList);
				topList.appendChild(listItem);
				controlContainer.setAttribute("id", "text-size");
				controlContainer.appendChild(topList);
				container.insertBefore(controlContainer, container.childNodes[0]);
			}
		}
	}
}


/*
	Text sizer function
*/
function textIt(str) {
	var wrap = document.getElementById("wrap");
	var textSize = document.getElementById("text-size");
	if (wrap && textSize) {
		wrap.className = str;

		var listItems = textSize.getElementsByTagName("li");
		for (var i = 0; i < listItems.length; i++) {
			listItems[i].className = "";	// IE5/Mac won't respect .removeAttribute("class"), for some reason.
			if (listItems[i].getAttribute("id") == str) {
				listItems[i].className = safeAppend(listItems[i].className, "current");
				setCookie("text-size", str, 365)
			}
		}
	}
}


/*-  Tabs for "Current Issue" module
----------------------------------------------------------------------*/
/*
	Build tabs for text sizing
*/
function buildCurrentIssueTabs() {
	var currentIssue = cssQuery(".module-current-issue");
	if (currentIssue && document.createElement) {
		var tabText = [];
		var tabIds = [];
		for (var i = 0; i < currentIssue.length; i++) {
			var forms = currentIssue[i].getElementsByTagName("form");
			for (var j = 0; j < forms.length; j++) {
				// Get the ids for our tabs
				tabIds.push(forms[j].getAttribute("id"));

				// Get the text for our tabs
				var legends = forms[j].getElementsByTagName("legend");
				for (var k = 0; k < legends.length; k++) {
					tabText.push(document.createTextNode(legends[k].innerHTML));
					legends[k].className = "ineffable";
				}
				if (j > 0) {
					forms[j].className = "ineffable";
				}
			}

			// Build the tabs
			var tabs = document.createElement("div");
			var list = document.createElement("ul");
			tabs.className = "tabs";

			for (var j = 0; j < tabText.length; j++) {
				var listItem = document.createElement("li");
				var anchor = document.createElement("a");

				anchor.setAttribute("href", "javascript:issueTab('" + tabIds[j] + "');");
				anchor.appendChild(tabText[j]);
				listItem.setAttribute("id", "tab-" + tabIds[j]);
				listItem.appendChild(anchor);
				if (j == 0) {
					listItem.className = "current first";
				} else if (j == (tabText.length - 1)) {
					listItem.className = "last";
				}
				list.appendChild(listItem);
			}

			tabs.appendChild(list);
			// Insert the tabs before the first form
			forms[0].parentNode.insertBefore(tabs, forms[0]);
		}
	}
}


/*
	Show/hide tabs for Current Issue
*/
function issueTab(id) {
	// Set some variables, and find out where we are in the document
	var cloak = "ineffable";
	var current = "current";
	var thisListItem = document.getElementById("tab-" + id);
	var tabDiv = getParent(thisListItem, "div");
	var contentDiv = tabDiv.parentNode;	// Not sure why getParent() returns tabDiv

	// Hide all of the forms, except the one that matches the id
	var forms = contentDiv.getElementsByTagName("form");
	for (var i = 0; i < forms.length; i++) {
		forms[i].className = safeAppend(forms[i].className, cloak);
		if (forms[i].getAttribute("id") == id) {
			forms[i].className = forms[i].className.replace(new RegExp("(( ?|^)" + cloak + "( |$))*"), "");
		}
	}

	// "Activate" the proper tab
	var listItems = tabDiv.getElementsByTagName("li");
	for (var i = 0; i < listItems.length; i++) {
		listItems[i].className = listItems[i].className.replace(new RegExp("( ?|^)current( |$)"), "");
		if ((listItems[i].getAttribute("id") == "tab-" + id)) {
			listItems[i].className = safeAppend(listItems[i].className, current);
		}
	}
}


/*-  When a user clicks on a text field, any default text should
	be removed.
----------------------------------------------------------------------*/
function initRemoveText() {
	if (document.getElementsByTagName) {
		var inputs = document.getElementsByTagName("input");
		for (var i = 0; i < inputs.length; i++) {
			var this_input = inputs[i];
			if (this_input.getAttribute("type") == "text") {
				this_input.setAttribute("previous", this_input.value);

				this_input.onclick = function() {
					this.value = "";
				}

				this_input.onblur = function() {
					if (this.value.length == 0) {
						this.value = this.getAttribute("previous");
					}
					this.setAttribute("previous", this.value);
				}
			}
		}
	}
}


/*-  Monitor the width of the page
----------------------------------------------------------------------*/
function widthMonitor() {
	if (document.getElementById && document.getElementsByTagName) {
		var body = document.getElementsByTagName("body")[0];
		if (!findWord("fixed", body.className)) {
			var docWidth = getBrowserWidth();
			var nav = document.getElementById("navigation");

			if (docWidth > 990) {
				nav.className = "full";
			} else if (docWidth <= 990 && docWidth > 903) {
				nav.className = "medium";
			} else if (docWidth <= 903 && docWidth > 800) {
				nav.className = "mini";
			} else if (docWidth <= 800) {
				nav.className = "micro";
			}
			/*
			var diagnostic = document.getElementById("text-size");
			diagnostic.innerHTML = docWidth;
			*/
		}
	}
}


/*-  Utility Functions
----------------------------------------------------------------------*/
/*
	Insert node after referenceNode in parent
*/
function insertAfter(parent, node, referenceNode) {
	parent.insertBefore(node, referenceNode.nextSibling);
}

/*
	Find full word (needle) in a string (haystack)
*/
function findWord(needle, haystack) {
	return haystack.match(needle + "\\b");
}

/*
	Used to replace a word (oldNeedle) with a new word (newNeedle), as found in a string (haystack)
*/
function replaceWord(oldNeedle, newNeedle, haystack) {
	return haystack.replace(new RegExp(oldNeedle + "\\b", "g"), newNeedle);
}

/*
	Smart string concatenation
*/
function safeAppend(target, str) {
	target += (target.length > 0 ? " ": "") + str;
	return target;
}


/*
	IE Fix: Son of Suckerfish (modified for IE5/Mac friendliness)
*/
function ieHover(els) {
	for (var i=0; i < els.length; i++) {
		els[i].onmouseover=function() {
			this.className = safeAppend(this.className, "ie-hover");
		}

		els[i].onmouseout = function() {
			this.className = this.className.replace(new RegExp("( ?|^)ie-hover\\b"), "");
		}
	}
}

/*
	Cookie functions
*/
// Set the cookie
function setCookie(name, value, days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = ";expires="+date.toGMTString();
	} else {
		expires = "";
	}
	document.cookie = name+"="+value+expires+";";
}

// Read the cookie
function readCookie(name) {
	var needle = name + "=";
	var cookieArray = document.cookie.split(';');
	for(var i=0;i < cookieArray.length;i++) {
		var pair = cookieArray[i];
		while (pair.charAt(0)==' ') {
			pair = pair.substring(1, pair.length);
		}
		if (pair.indexOf(needle) == 0) {
			return pair.substring(needle.length, pair.length);
		}
	}
	return null;
}


/*
	Get Browser Width
*/
function getBrowserWidth() {
	if (window.innerWidth) {
		return window.innerWidth;
	} else if (document.documentElement && document.documentElement.clientWidth != 0) {
		return document.documentElement.clientWidth;
	} else if (document.body) {
		return document.body.clientWidth;
	}
	return 0;
}


/*
	Add Load Event
*/
function addLoadEvent(func) {
	var oldonload = window.onload;
	if (typeof window.onload != 'function') {
		window.onload = func;
	} else {
		window.onload = function() {
			oldonload();
			func();
		}
	}
}


/*
	Add Resize Event
*/
function addResizeEvent(func) {
	var oldresize = window.onresize;
	if (typeof window.onresize != 'function') {
		window.onresize = func;
	} else {
		window.onresize = function() {
			oldresize();
			func();
		}
	}
}


/*
	Get parent element
*/
function getParent(el, pTagName) {
	if (el == null) return null;
	else if (el.nodeType == 1 && el.tagName.toLowerCase() == pTagName.toLowerCase())	// Gecko bug, supposed to be uppercase
		return el;
	else
		return getParent(el.parentNode, pTagName);
}


/*
	Get Inner Text
*/
function getInnerText(el) {
	if (typeof el == "string") return el;
	if (typeof el == "undefined") { return el };
	if (el.innerText) return el.innerText;	//Not needed but it is faster
	var str = "";
	
	var cs = el.childNodes;
	var l = cs.length;
	for (var i = 0; i < l; i++) {
		switch (cs[i].nodeType) {
			case 1: //ELEMENT_NODE
				str += getInnerText(cs[i]);
				break;
			case 3:	//TEXT_NODE
				str += cs[i].nodeValue;
				break;
		}
	}
	return str;
}
