// IOTBS2.1 :: Invasion of the Body Switchers - Look Who's Switching Too
// >>> "Original"
//      Generates the switching controls as forms and selectors
// ***********************************************
// This copyright statement must remain in place for both personal and commercial use
// GNU General Public License -- http://www.gnu.org/copyleft/gpl.html
// ***********************************************
// Original concept by Andy Clarke -- http://www.stuffandnonsense.co.uk/
// DOM scripting by brothercake -- http://www.brothercake.com/
// Create element and attributes based on a method by beetle -- http://www.peterbailey.net/
//************************************************
function bodySwitcher(divid, label, isnative){if(switcher.path != null && !switcher.isie && typeof isnative != 'undefined' && isnative == 'yes'){switcher.integrate(this, divid );}this.classes = [];if(document.getElementById(divid) == null) { return false; }var self = this;this.options = 0;var attrs = { 'action' : '' };var frm = document.getElementById(divid).appendChild(switcher.create('form', attrs));var fieldset = frm.appendChild(switcher.create('fieldset'));attrs = { 'for' : 'select-' + divid };var labele = fieldset.appendChild(switcher.create('label', attrs));attrs = { 'text' : label };labele.appendChild(switcher.create('span', attrs));attrs = { 'id' : 'select-' + divid };this.select = labele.appendChild(switcher.create('select', attrs));this.select.onchange = function(){switcher.save(this.id.replace('select-', ''), this.options[this.options.selectedIndex].value, this.options.selectedIndex, self );};return true;};bodySwitcher.prototype.defineClass = function(key, val){this.classes[this.classes.length] = key;if(typeof this.select == 'undefined') { return false; }var attrs = { 'value' : key, 'text' : val };this.select.appendChild(switcher.create('option', attrs));if(switcher.cookie != null){if(switcher.cookie.indexOf(' ' + key + ' ')!=-1){this.select.selectedIndex = this.options;}}this.options ++;return true;};bodySwitcher.prototype.update = function(ind){if(typeof this.select != 'undefined'){this.select.selectedIndex = ind;}};