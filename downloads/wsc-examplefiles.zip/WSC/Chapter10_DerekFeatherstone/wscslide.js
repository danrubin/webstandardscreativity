
var SLIDEINTERVAL = 65;
var revealTimer = null;
var moving  = false;


function changeHeight(elt, dH) {
var thiselt = document.getElementById(elt);

	
	// is this a reveal up or down? if up, the final target height is 0
	var targetHeight = (dH < 0) ? 0 : dH;
	
	
	// the current height of the element
	var currHeight = thiselt.offsetHeight;

	// the change in height required - to smooth the transition we reveal
	// half of the remaining height of the pane with each iteration
	var dHeight = Math.ceil((targetHeight - currHeight) / 2);

	newHeight = currHeight + dHeight;
	
	
	// if the difference is less than 1 pixel we'll stop moving, clear the
	// interval and set the height to the exact height we started with
		if (Math.abs(dHeight) <= 1) {
			clearInterval(revealTimer);
			moving = false;
			newHeight = targetHeight;		
			}

// set the height to a new value
thiselt.style.height =  newHeight + "px"; 

// if the height is now zero, we need to remove the "exposed" state
// set the height back to the original height and clear the JS set value
// for height so that it is reset to the value found in the original CSS
if (thiselt.offsetHeight == 0) {
	thiselt.className = thiselt.className.replace(/exposed/g,'');
	 //force a repaint for getting around Safari rendering issue
        thiselt.innerHTML = thiselt.innerHTML + '';
	thiselt.style.height = '';
}
	
	
}

function Reveal(elt, dH) {

	// prevent the function from doing anything if it is already active
	if (moving) return;

	var thiselt = document.getElementById(elt);

	if (/exposed/i.test(thiselt.className)) {
			// if we are exposed, we want to slide the pane up instead of down
			dH = -dH;
						
	} else {
			// this opens the tab and respects classes that already exist
			
			thiselt.className += " exposed";
	}

	moving = true;	
	
	// run the changeHeight function at the specified interval; will run until we clear the interval
	revealTimer = setInterval("changeHeight('" + thiselt.id + "','" + dH + "')", SLIDEINTERVAL);
  
}
