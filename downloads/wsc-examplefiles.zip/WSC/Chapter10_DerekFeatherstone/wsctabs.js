var slideready = false;

window.onload = function() { 
	slideready = true;
}

function toggle(element) { 

	if (!slideready || moving) return false;

	reset(element);

	if (!document.getElementById) return true;

	var elt = document.getElementById(element);
	var initialheight= elt.offsetHeight;

	Reveal(element, initialheight);

	elt.tabIndex = -1;
	elt.focus();

	return false;
}

/* reset function used to set all navigation pane divs back to their initial state */

function reset(element) {
	var elt = document.getElementById('drops');
	var elts = elt.getElementsByTagName('div');
	var exposed = document.getElementById(element);

  
	for (i=0; i< elts.length; i++) {

		// we only want to reset divs that are acting as navigation panes
		// and exclude the current one that has been set to "exposed"
		if (!/drop-/i.test(elts[i].id) || (exposed == document.getElementById(elts[i].id))) {
		continue;
		}
		
		thiselt = elts[i];
		
		thiselt.className = thiselt.className.replace(/exposed/g,'')

	}

	return;
	
}
